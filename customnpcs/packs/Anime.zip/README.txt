MESSAGE FROM GAULTHUNTER - INFORMATION                                                     |
-------------------------------------------------------------------------------------------/
AnimePack Release 3

BY UPLOADING THIS SKINPACK I agree to never rate this skinpack myself, as not to give
myself an unfair rating. I may ask Noppes or the community to rate this with each update.
I ALSO agree to never upload a skin against the rules I set.
I ALSO acknowledge that I will never be nominated for any festivities including, but not
limited to, skins of the month, or other possible future accolade system as to prevent bias.
I ALSO confirm that each skin in this pack was created by me, the characters belong to their
respective companies, who have been given credit in the form of links to their wikipedia
pages.

BY USING THIS SKINPACK you agree to not distribute them without due credit. This
readme in it's unmodified form is a sufficient credit, as is my username.
(gaulthunter, OR DiggyDiggyHole1223)


I can't do anything if you DON'T read the readme, so let's go by the honor system.
--------------------------------------------------------------------------------------------
ANIMES INCLUDED:
-Vocaloid --http://en.wikipedia.org/wiki/Vocaloid
-Girls Bravo --Not reccomended for people whom are underage. http://en.wikipedia.org/wiki/Girls_Bravo
-Angel Beats! --http://en.wikipedia.org/wiki/Angel_Beats!
-Fullmetal Alchemist --http://en.wikipedia.org/wiki/Fullmetal_Alchemist
-Nichijou --http://en.wikipedia.org/wiki/Nichijou
-Kagerou Days --http://vocaloid.wikia.com/wiki/Kagerou_Project
-Chobits
-Hetalia
-Other (These are skins specially made by request on my MCF thread)



This skinpack is constantly being updated. Some folders will be empty, others may be
stuffed.

You can download each skin individually from my skindex page.
http://www.minecraftskins.com/346230/gaulthunter/

The skins there will include some not yet included in the pack.

This skinpack has not recieved a rating in order to prevent bias.

The skins in this pack have all been hand made using SkinEdit. With the exception of adding
'noise'. The skin 'Rin Kagamine' was not made from scratch, she was modified by my Len skin
because of the high likeness.

If you have a suggestion for this skinpack, send it to gaulthunter@hotmail.com

Please do not suggest an anime which already has a folder reserved

If you have a skinpack to submit to the Noppes' Custom NPC packs page, send it to
gaulthunter@hotmail.com

Please do not submit inappropriate skins

If you want all of my money, I have none

If you want to donate, I'm a minor, so I cannot accept it. Noppes would be glad to accept.

If you think i'm rambling, you're probably right

ONLY send an email to gaulthunter@hotmail.com if it pertains to Noppes' Custom NPC mod.
I have no affiliation with his other mods, but if you would like to give him praise, I'll
gladly pass on the message.

UPCOMING SKINS ON MY TODO:
*Gumi
*Alphonse Elric
*Meiko
*Winry Rockbell
*Kazahara Fukuyama
*Yuzuru Otanashi
*Yurippe Nakamura
*TK
*Yui
*Hideki Motosuwa


CHANGELOG HAS BEEN MOVED TO IT'S OWN .txt!

If any part of this readme does not make sense, contact me at gaulthunter@hotmail.com and I
will clarify.

CREDITS - Thank these people/companies for the mangas and animes that inspired and populate
this pack!
--------------------------------------------------------------------------------------------
Funimation - Fullmetal Alchemist, Girls Bravo
Yamaha - Vocaloid
Ameya/Ayame - Utau
Jun Maeda - Angel Beats!
Jin - Kagerou Days
Nichijou - Arai Keiichi


